const container = document.getElementById('heart-container');
const totalElements = 150; // Cuántas frases quieres

for (let i = 0; i < totalElements; i++) {
    const angle = (i / totalElements) * Math.PI * 2;
    
    // Ecuación del corazón
    const x = 16 * Math.pow(Math.sin(angle), 3);
    const y = -(13 * Math.cos(angle) - 5 * Math.cos(2 * angle) - 2 * Math.cos(3 * angle) - Math.cos(4 * angle));

    const span = document.createElement('span');
    span.className = 'love-text';
    span.innerText = 'I love you';

    // Ajustar escala y posición al centro
    const posX = x * 15 + 300; 
    const posY = y * 15 + 300;

    span.style.left = `${posX}px`;
    span.style.top = `${posY}px`;
    
    // Retraso de animación aleatorio para que se vea natural
    span.style.animationDelay = `${Math.random() * 2}s`;

    container.appendChild(span);
}